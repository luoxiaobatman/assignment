package com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.order;

public class Order {
    private Long id;
}
