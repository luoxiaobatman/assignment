package com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.order.dao;

import com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.product.Product;

/**
 * 订单 persistent layer
 */
public class OrderDAO {
    /**
     * 产生一个产品销售的订单
     */
    public void insertOrder(Product product) {

    }
}
