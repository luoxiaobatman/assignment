package com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.order.service;

import com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.product.Product;

public interface IOrderService {
    void placeAnOrder(Product product);
}
