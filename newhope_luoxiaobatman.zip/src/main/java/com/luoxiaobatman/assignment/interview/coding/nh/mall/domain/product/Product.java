package com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.product;

public class Product {
    private Long id;
}
