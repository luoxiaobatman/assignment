package com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.product.service;

import com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.product.Product;

public interface IProductService {
    String buyProduct(Product product);
}
