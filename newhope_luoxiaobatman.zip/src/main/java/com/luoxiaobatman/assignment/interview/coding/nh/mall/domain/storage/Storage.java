package com.luoxiaobatman.assignment.interview.coding.nh.mall.domain.storage;

public class Storage {
}
