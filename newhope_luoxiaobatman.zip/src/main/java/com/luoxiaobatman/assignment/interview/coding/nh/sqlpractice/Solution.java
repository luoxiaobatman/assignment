package com.luoxiaobatman.assignment.interview.coding.nh.sqlpractice;

/**
 * sql
 */
public class Solution {
}
